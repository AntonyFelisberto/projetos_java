package udemy.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class OperacionesDB extends TiendaDB {
	public void createProduct(Producto producto) throws ClassNotFoundException, SQLException {
		Connection connection = super.getConnection();
		String sqlCreateProduct = "INSERT INTO Productos (ProductoID, Nombre, "
				+ "Descripcion, Precio, Cantidad) VALUES (?,?,?,?,?);";
		PreparedStatement preparedStatement = connection.prepareStatement(sqlCreateProduct);
		String productID = UUID.randomUUID().toString();
		preparedStatement.setString(1, productID);
		preparedStatement.setString(2, producto.getNombre());
		preparedStatement.setString(3, producto.getDescripcion());
		preparedStatement.setDouble(4, producto.getPrecio());
		preparedStatement.setInt(5, producto.getCantidad());
		preparedStatement.execute();
		System.out.println("Producto agregado correctamente.");
		System.out.println(producto.toString());
	}
	public void getProductByID(String productID) throws ClassNotFoundException, SQLException {
		Connection connection = super.getConnection();
		String sqlGetProductByID = "SELECT * FROM Productos WHERE ProductoID=?";
		PreparedStatement preparedStatement = connection.prepareStatement(sqlGetProductByID);
		preparedStatement.setString(1, productID);
		ResultSet resultado = preparedStatement.executeQuery();
		if(resultado.next()) {
			System.out.println("Se encontr� informaci�n del producto");
			Producto producto = new Producto(resultado.getString("ProductoID"), 
					resultado.getString("Nombre"), resultado.getString("Descripcion"),
					resultado.getDouble("Precio"), resultado.getInt("Cantidad"));
			System.out.println(producto.toString());
		}
	}
	
	public void updateProductByID(String productID) throws ClassNotFoundException, SQLException {
		Connection connection = super.getConnection();
		String sqlUpdateProductByID = "UPDATE Productos SET Precio=?, "
				+ "Cantidad=? WHERE ProductoID=?";
		PreparedStatement preparedStatement = connection.prepareStatement(sqlUpdateProductByID);
		preparedStatement.setDouble(1, Math.random()*50+1);
		preparedStatement.setInt(2, (int)(Math.random()*30+1));
		preparedStatement.setString(3, productID);
		preparedStatement.execute();
		System.out.println("Producto actualizado correctamente");
	}
	
	public void deleteProductByID(String productID) throws ClassNotFoundException, SQLException {
		Connection connection = super.getConnection();
		String sqlDeleteProductByID = "DELETE FROM Productos WHERE ProductoID=?";
		PreparedStatement preparedStament = connection.prepareStatement(sqlDeleteProductByID);
		preparedStament.setString(1, productID);
		preparedStament.execute();
		System.out.println("Producto eliminado correctamente.");
	}
}
