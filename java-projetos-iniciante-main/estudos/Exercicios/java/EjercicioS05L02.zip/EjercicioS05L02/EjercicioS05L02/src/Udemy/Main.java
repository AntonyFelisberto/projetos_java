package Udemy;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		//Expreciones regulares
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		String passRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
		
		System.out.print("Crear una nueva cuenta:\n" + "Ingresa un correo: ");
		String emailInput = scanner.nextLine();
		System.out.print("Ingresa su contraseña: ");
		String passInput = scanner.nextLine();	
		
		AccountCreate account = new AccountCreate(emailInput, passInput);
		
		//validar cuenta
		Validate validate = new Validate(emailRegex, passRegex);
		if(validate.validateEmail(account.getEmail()) && validate.validatePass(account.getPass())) {
			System.out.println("La cuenta fue creada con exito");
		} else {
			System.out.println("La cuenta no cumple con los requisitos necesarios.");
			System.out.println("El correo debe de llevar @correo.com\n"
					+ "La contraseña debe tener mayusculas (R,A,C), numeros (12545) , y una expresion (!,/,%");
		}
	}

}
