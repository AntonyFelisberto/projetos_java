package Udemy;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validate {
	private String emailRegex;
	private String passRegex;
	
	public Validate(String emailRegex, String passRegex) {
		this.emailRegex = emailRegex;
		this.passRegex = passRegex;
	}
	
	public boolean validateEmail(String email) {
		Pattern pattern = Pattern.compile(emailRegex);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	
	public boolean validatePass(String pass) {
		Pattern pattern = Pattern.compile(passRegex);
		Matcher matcher = pattern.matcher(pass);
		return matcher.matches();
	}
}
