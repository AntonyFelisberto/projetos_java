package Udemy;

public class AccountCreate {
	private String email;
	private String pass;
	
	public AccountCreate(String email, String pass) {
		this.email = email;
		this.pass = pass;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPass() {
		return pass;
	}
}
