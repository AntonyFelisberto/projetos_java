package udemy.interfaces;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import nu.pattern.OpenCV;

public class Figuras implements DibujarFiguras {
	private Mat imagenBase;
	private Scalar colorFondo;
	private int grosor;
	private Point esquina1;
	private Point esquina2;
	private Point centro;
	private Scalar colorLinea;
	private int radio;
	
	/**Constructor para dibujar rectangulo*/
	public Figuras(int x1, int y1, int x2, int y2) {
		this.inicializarImagen();
		this.esquina1 = new Point(x1,y1);
		this.esquina2 = new Point(x2,y2);
	}
	
	/**Constructor para dibujar circulo*/
	public Figuras(int centroX, int centroY, int radio) {
		this.inicializarImagen();
		this.centro = new Point(centroX, centroY);
		this.radio = radio;
	}
	
	private void inicializarImagen() {
		OpenCV.loadLocally();
		this.imagenBase = new Mat(600,600,CvType.CV_8UC3);
		this.colorFondo = new Scalar(255,255,255);
		this.colorLinea = new Scalar(0,0,0);
		this.imagenBase.setTo(this.colorFondo);
		this.grosor = 2;
	}
	
	public void dibujarRectangulo() {
		Imgproc.rectangle(imagenBase, esquina1, esquina2, colorLinea, grosor);
		Imgcodecs.imwrite("rectangulo.jpg", imagenBase);
		HighGui.imshow("Rectangulo", imagenBase);
		HighGui.waitKey();
	}

	public void dibujarCirculo() {
		Imgproc.circle(imagenBase, centro, radio, colorLinea, grosor);
		Imgcodecs.imwrite("circulo.jpg", imagenBase);
		HighGui.imshow("Circulo", imagenBase);
		HighGui.waitKey();
	}

	public Mat getImagenBase() {
		return imagenBase;
	}

	public void setImagenBase(Mat imagenBase) {
		this.imagenBase = imagenBase;
	}

	public Scalar getColorFondo() {
		return colorFondo;
	}

	public void setColorFondo(Scalar colorFondo) {
		this.colorFondo = colorFondo;
	}

	public int getGrosor() {
		return grosor;
	}

	public void setGrosor(int grosor) {
		this.grosor = grosor;
	}

	public Point getEsquina1() {
		return esquina1;
	}

	public void setEsquina1(Point esquina1) {
		this.esquina1 = esquina1;
	}

	public Point getEsquina2() {
		return esquina2;
	}

	public void setEsquina2(Point esquina2) {
		this.esquina2 = esquina2;
	}

	public Point getCentro() {
		return centro;
	}

	public void setCentro(Point centro) {
		this.centro = centro;
	}

	public Scalar getColorLinea() {
		return colorLinea;
	}

	public void setColorLinea(Scalar colorLinea) {
		this.colorLinea = colorLinea;
	}

	public int getRadio() {
		return radio;
	}

	public void setRadio(int radio) {
		this.radio = radio;
	}
}