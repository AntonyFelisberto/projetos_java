package udemy.interfaces;

import org.opencv.core.Mat;
import org.opencv.core.Scalar;

public class AppInterfaces {

	public static void main(String[] args) {
		Figuras rectangulo = new Figuras(100, 100, 500, 300);
		Scalar colorFondo1 = new Scalar(241, 214, 174);
		Mat imagenBase1 = rectangulo.getImagenBase();
		imagenBase1.setTo(colorFondo1);
		rectangulo.setGrosor(5);
		rectangulo.dibujarRectangulo();
		
		Figuras circulo = new Figuras(300, 200, 150);
		circulo.dibujarCirculo();
	}

}

