package udemy.interfaces;

public interface DibujarFiguras {
	void dibujarRectangulo();
	void dibujarCirculo();
}
