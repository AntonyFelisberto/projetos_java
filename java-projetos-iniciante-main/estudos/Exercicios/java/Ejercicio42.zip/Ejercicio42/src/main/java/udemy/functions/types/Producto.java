package udemy.functions.types;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain=true)
public class Producto {
	private String productoID;
	private String nombre;
	private String descripcion;
	private double precio;
	private int cantidad;
}
