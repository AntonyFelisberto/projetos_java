package udemy.functions.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import lombok.Setter;

@Setter
public class TiendaDB {
	private Connection connection = null;

	public Connection getConnection() throws SQLException {
		String username = System.getenv().get("USER_DB");
		String password = System.getenv().get("PASSWORD_DB");
		this.connection = DriverManager.getConnection("jdbc:mysql://database-udemy.mysql.database.azure.com/TiendaDB", 
				username, password);
		if(this.connection != null) {
			System.out.println("Conexion creada correctamente");
			return this.connection;
		}else {
			System.out.println("No fue posible crear la conexion");
		}
		return connection;
	}
}
